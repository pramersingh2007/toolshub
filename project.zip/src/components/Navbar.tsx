"use client";

import Link from "next/link";
import { ThemeToggle } from "./ThemeToggle";
import { Button } from "@/components/ui/button";
import { Hammer, Menu, X, ChevronRight, LayoutGrid } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="w-full z-[120] px-4 py-4 md:px-12 transition-all duration-500">
      <div className="max-w-7xl mx-auto rounded-[2rem] glass shadow-2xl px-8 py-3">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Link href="/" className="flex items-center gap-3 group">
              <div className="bg-primary p-2.5 rounded-2xl text-primary-foreground group-hover:rotate-12 transition-all shadow-xl shadow-primary/20">
                <Hammer className="h-6 w-6" />
              </div>
              <span className="text-2xl font-black tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-primary to-accent">
                ToolForge
              </span>
            </Link>
          </div>

          <div className="hidden md:flex items-center space-x-10">
            <div className="flex items-center gap-8">
              <Link href="/categories/pdf-tools" className="text-sm font-bold text-muted-foreground hover:text-primary transition-colors">PDF Suite</Link>
              <Link href="/categories/image-tools" className="text-sm font-bold text-muted-foreground hover:text-primary transition-colors">Image Lab</Link>
              <Link href="/categories/developer-tools" className="text-sm font-bold text-muted-foreground hover:text-primary transition-colors">Dev Hub</Link>
              <Link href="/categories" className="flex items-center gap-2 text-sm font-bold text-primary group">
                <LayoutGrid className="h-4 w-4" />
                Browse All
              </Link>
            </div>
            <div className="h-8 w-px bg-border/40 mx-2" />
            <div className="flex items-center gap-4">
              <ThemeToggle />
              <Button className="font-black rounded-2xl px-8 py-6 bg-primary hover:shadow-2xl hover:shadow-primary/40 transition-all hover:scale-105 active:scale-95">
                Sign In
              </Button>
            </div>
          </div>

          <div className="flex md:hidden items-center gap-4">
            <ThemeToggle />
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)} 
              className="p-3 rounded-2xl bg-secondary text-foreground hover:bg-secondary/80 transition-all active:scale-90"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className={cn(
        "md:hidden fixed inset-4 top-24 z-[130] glass rounded-[3rem] shadow-[0_40px_100px_rgba(0,0,0,0.3)] transition-all duration-500 ease-[cubic-bezier(0.23,1,0.32,1)] origin-top overflow-hidden",
        isMenuOpen ? "scale-100 opacity-100" : "scale-95 opacity-0 pointer-events-none"
      )}>
        <div className="p-8 space-y-4">
          <div className="px-4 py-2 text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60 mb-2">Main Menu</div>
          <Link onClick={() => setIsMenuOpen(false)} href="/categories/pdf-tools" className="flex items-center justify-between p-6 rounded-3xl hover:bg-primary/5 transition-all text-xl font-black">
            PDF Suite <ChevronRight className="h-6 w-6 opacity-30" />
          </Link>
          <Link onClick={() => setIsMenuOpen(false)} href="/categories/image-tools" className="flex items-center justify-between p-6 rounded-3xl hover:bg-primary/5 transition-all text-xl font-black">
            Image Lab <ChevronRight className="h-6 w-6 opacity-30" />
          </Link>
          <Link onClick={() => setIsMenuOpen(false)} href="/categories/developer-tools" className="flex items-center justify-between p-6 rounded-3xl hover:bg-primary/5 transition-all text-xl font-black">
            Dev Hub <ChevronRight className="h-6 w-6 opacity-30" />
          </Link>
          <div className="pt-8 space-y-4">
            <Button className="w-full py-8 text-xl font-black rounded-3xl shadow-2xl shadow-primary/20">Get Started Free</Button>
            <Button variant="outline" className="w-full py-8 text-xl font-black rounded-3xl glass">Login to Account</Button>
          </div>
        </div>
      </div>
    </header>
  );
}
